// ===== Strong scraper for all required fields =====
function scrapeData() {
  const data = {
    'Transaction ID': '',
    'Member Name': '',
    'Member ID': '',
    'Date of Birth': '',
    'Gender': '',
    'Address': '',
    'Group Number': '',
    'Plan Begin Date': '',
    'Plan Name': '',
    'Payer': '',
    'Coverage Status': '',
    'Identifier Code': ''
  };

  // --- Transaction ID ---
  const titleEl = document.querySelector('.summary__value');
  if (titleEl) {
    const t = (titleEl.innerText || '').trim();
    if (/Transaction ID/i.test(t)) {
      data['Transaction ID'] = t.replace(/Transaction ID:?/i, '').trim();
    }
  }
  if (!data['Transaction ID']) {
    const m = (document.body.innerText || '').match(/Transaction ID[:\s]*([A-Z0-9\-]+)/i);
    if (m) data['Transaction ID'] = m[1].trim();
  }

  // --- All .summary__group labels ---
  document.querySelectorAll('.summary__group').forEach(group => {
    const label = (group.querySelector('.summary__label')?.innerText || '').trim();
    const value = (group.querySelector('.summary__value')?.innerText || '').trim().replace(/\n+/g, ' ');
    if (!label || !value) return;

    const l = label.toLowerCase();
    if (l.includes('member name') || l === 'name') data['Member Name'] = value;
    else if (l.includes('member id') || l.includes('subscriber id') || l === 'id') data['Member ID'] = value;
    else if (l.includes('date of birth') || l.includes('dob') || l.includes('birth')) data['Date of Birth'] = value;
    else if (l.includes('gender') || l.includes('sex')) data['Gender'] = value;
    else if (l.includes('address')) data['Address'] = value;
    else if (l.includes('group number') || l.includes('group #') || l.includes('group id')) data['Group Number'] = value;
    else if (l.includes('plan begin') || l.includes('effective') || l.includes('start date')) data['Plan Begin Date'] = value;
    else if (l.includes('plan name') || l.includes('plan type')) data['Plan Name'] = value;
    else if (l.includes('identifier code') || l.includes('identifier')) data['Identifier Code'] = value;
    else if (l.includes('transaction')) data['Transaction ID'] = data['Transaction ID'] || value;
    // keep original label too if useful
    else data[label] = value;
  });

  // --- Extra text fallbacks for missing fields ---
  const body = document.body.innerText || '';

  if (!data['Member Name']) {
    const m = body.match(/Member Name[:\s]*([^\n]+)/i);
    if (m) data['Member Name'] = m[1].trim();
  }
  if (!data['Member ID']) {
    const m = body.match(/(?:Member ID|Subscriber ID)[:\s]*([A-Z0-9\-]+)/i);
    if (m) data['Member ID'] = m[1].trim();
  }
  if (!data['Date of Birth']) {
    const m = body.match(/(?:Date of Birth|DOB)[:\s]*([0-9\/\-]+)/i);
    if (m) data['Date of Birth'] = m[1].trim();
  }
  if (!data['Gender']) {
    const m = body.match(/Gender[:\s]*(Male|Female|M|F|Other)/i);
    if (m) data['Gender'] = m[1].trim();
  }
  if (!data['Address']) {
    const m = body.match(/Address[:\s]*([^\n]+)/i);
    if (m) data['Address'] = m[1].trim();
  }
  if (!data['Group Number']) {
    const m = body.match(/Group (?:Number|#|ID)[:\s]*([A-Z0-9\-]+)/i);
    if (m) data['Group Number'] = m[1].trim();
  }
  if (!data['Plan Begin Date']) {
    const m = body.match(/(?:Plan Begin Date|Effective Date|Start Date)[:\s]*([0-9\/\-]+)/i);
    if (m) data['Plan Begin Date'] = m[1].trim();
  }
  if (!data['Plan Name']) {
    const m = body.match(/Plan Name[:\s]*([^\n]+)/i);
    if (m) data['Plan Name'] = m[1].trim();
  }

  // --- Payer button ---
  const payerBtn = document.querySelector('button.btn.payer, button.payer, .btn.payer');
  if (payerBtn) {
    const nameEl = payerBtn.querySelector('.fs-18, .fw-500, p:not(.payer__label)');
    if (nameEl) data['Payer'] = nameEl.innerText.trim();
    else {
      const all = payerBtn.innerText.replace(/Payer/i, '').replace(/Active Coverage|Inactive/i, '').trim();
      if (all) data['Payer'] = all;
    }
    const statusEl = payerBtn.querySelector('.payer__status, .payer__coverage');
    if (statusEl) data['Coverage Status'] = statusEl.innerText.trim();
  }
  if (!data['Coverage Status'] && /Active Coverage/i.test(body)) {
    data['Coverage Status'] = 'Active Coverage';
  }
  if (!data['Payer']) {
    const m = body.match(/Payer[:\s]*([^\n]+)/i);
    if (m) data['Payer'] = m[1].replace(/Active Coverage|Inactive/i, '').trim();
  }

  // --- Identifier Code (subgroup pill) ---
  if (!data['Identifier Code']) {
    const idTitle = Array.from(document.querySelectorAll('.subgroup__title, .subgroup__pill, span, div, p, label'))
      .find(el => /Identifier Code/i.test(el.innerText || '') && (el.innerText || '').trim().length < 40);
    if (idTitle) {
      const group = idTitle.closest('.subgroup, .summary__group, [class*="subgroup"], [class*="group"]') || idTitle.parentElement;
      if (group) {
        const candidates = group.querySelectorAll('.subgroup__value, .summary__value, .fs-14, .fs-16, .fw-500, span, p, div');
        for (const c of candidates) {
          const txt = (c.innerText || '').trim();
          if (txt && !/Identifier Code/i.test(txt) && txt.length > 1 && txt.length < 50) {
            data['Identifier Code'] = txt;
            break;
          }
        }
        if (!data['Identifier Code'] && idTitle.nextElementSibling) {
          const next = (idTitle.nextElementSibling.innerText || '').trim();
          if (next && !/Identifier Code/i.test(next)) data['Identifier Code'] = next;
        }
      }
    }
    if (!data['Identifier Code']) {
      const m = body.match(/Identifier Code[:\s]*([A-Z0-9\-]+)/i);
      if (m) data['Identifier Code'] = m[1].trim();
    }
  }

  // Remove empty keys so CSV stays clean (optional – keep all for consistent headers)
  // We keep all keys for consistent columns
  return data;
}

// Single page button (still useful)
function createButtons() {
  if (document.getElementById('oa-scraper-box')) return;
  const box = document.createElement('div');
  box.id = 'oa-scraper-box';
  box.style.cssText = 'position:fixed;top:18px;right:18px;z-index:99999;display:flex;gap:10px;font-family:system-ui,sans-serif;';

  const csvBtn = document.createElement('button');
  csvBtn.id = 'oa-csv-btn';
  csvBtn.innerText = '⬇ CSV';
  csvBtn.style.cssText = 'padding:11px 16px;background:#2563eb;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.18);';
  csvBtn.onclick = () => {
    const data = scrapeData();
    if (!Object.values(data).some(v => v)) {
      alert('Koi data nahi mila!');
      return;
    }
    const headers = Object.keys(data);
    const values = headers.map(h => `"${String(data[h] || '').replace(/"/g, '""')}"`);
    const csv = headers.join(',') + '\n' + values.join(',');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `OfficeAlly_${data['Transaction ID'] || data['Member ID'] || Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };
  box.appendChild(csvBtn);
  document.body.appendChild(box);
}

createButtons();

// Message listener for bulk
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'scrape') {
    sendResponse({ fields: scrapeData() });
  }
  return true;
});

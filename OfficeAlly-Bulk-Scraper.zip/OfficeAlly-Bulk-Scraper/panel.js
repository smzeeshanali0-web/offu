const $ = (id) => document.getElementById(id);
const linksEl = $('links');
const workersEl = $('workers');
const delayEl = $('delay');
const perFileEl = $('perFile');
const autoSaveEl = $('autoSave');
const startBtn = $('start');
const stopBtn = $('stop');
const downloadBtn = $('download');
const dlFailedBtn = $('dlFailed');
const retryBtn = $('retry');
const clearBtn = $('clear');
const logEl = $('log');
const tbody = $('tbody');
const countEl = $('count');
const runCountEl = $('runCount');
const statusEl = $('status');
const barFill = $('barFill');
const failedEl = $('failedLinks');
const failedCountEl = $('failedCount');
const tableNote = $('tableNote');

const COLUMNS = [
  'Transaction ID', 'Member Name', 'Member ID', 'Date of Birth', 'Gender', 'Address',
  'Group Number', 'Plan Begin Date', 'Plan Name', 'Payer', 'Coverage Status', 'Identifier Code'
];
const CSV_COLUMNS = [...COLUMNS, 'Source Link'];
const TABLE_LIMIT = 200;

let results = [];
let failedLinks = [];
let savedCount = 0; // rows already auto-saved
let running = false;

// Keep background worker alive while panel is open
const port = chrome.runtime.connect({ name: 'keepalive' });
setInterval(() => { try { port.postMessage('ping'); } catch (e) {} }, 20000);

// ---------- helpers ----------
function log(text, type = '') {
  const d = document.createElement('div');
  d.className = type;
  d.textContent = `[${new Date().toLocaleTimeString()}] ${text}`;
  logEl.appendChild(d);
  while (logEl.children.length > 400) logEl.removeChild(logEl.firstChild);
  logEl.scrollTop = logEl.scrollHeight;
}

const escapeHtml = (s) =>
  String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

let renderQueued = false;
function renderTable() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => {
    renderQueued = false;
    countEl.textContent = results.length;
    updateButtons();

    if (!results.length) {
      tbody.innerHTML = '<tr><td colspan="13" class="empty">No data yet — links paste karke Start dabao</td></tr>';
      tableNote.textContent = '';
      return;
    }
    const offset = Math.max(0, results.length - TABLE_LIMIT);
    tbody.innerHTML = results.slice(offset).map((row, i) => {
      const cells = COLUMNS.map((c) => {
        const v = row[c] || '';
        return `<td title="${escapeHtml(v)}">${escapeHtml(v)}</td>`;
      }).join('');
      return `<tr><td>${offset + i + 1}</td>${cells}</tr>`;
    }).join('');
    tableNote.textContent = offset
      ? `Table me sirf last ${TABLE_LIMIT} rows dikh rahi hain. Download me saari ${results.length} rows aayengi.`
      : '';
  });
}

function renderFailed() {
  failedCountEl.textContent = failedLinks.length;
  failedEl.value = failedLinks.join('\n');
  updateButtons();
}

function updateButtons() {
  downloadBtn.disabled = results.length === 0;
  dlFailedBtn.disabled = failedLinks.length === 0;
  retryBtn.disabled = failedLinks.length === 0 || running;
}

function setRunning(r) {
  running = r;
  startBtn.disabled = r;
  stopBtn.disabled = !r;
  statusEl.textContent = r ? 'Running...' : 'Idle';
  updateButtons();
}

// ---------- CSV / downloads ----------
const q = (v) => `"${String(v || '').replace(/"/g, '""')}"`;

function buildCsv(rows) {
  const lines = [CSV_COLUMNS.map(q).join(',')];
  rows.forEach((row) => lines.push(CSV_COLUMNS.map((c) => q(row[c])).join(',')));
  return '\ufeff' + lines.join('\n');
}

function saveFile(text, name, type = 'text/csv;charset=utf-8;') {
  const url = URL.createObjectURL(new Blob([text], { type }));
  return new Promise((resolve) => {
    chrome.downloads.download(
      { url, filename: `OfficeAlly/${name}`, saveAs: false, conflictAction: 'uniquify' },
      () => {
        void chrome.runtime.lastError;
        setTimeout(() => URL.revokeObjectURL(url), 60000);
        resolve();
      }
    );
  });
}

// perFile = 0 -> one file; else split into files of perFile rows each
async function saveCsvFiles(rows, perFile, prefix) {
  if (!rows.length) return 0;
  const size = perFile > 0 ? perFile : rows.length;
  const parts = Math.ceil(rows.length / size);
  for (let p = 0; p < parts; p++) {
    const slice = rows.slice(p * size, (p + 1) * size);
    const name = parts === 1 ? `${prefix}.csv` : `${prefix}_part${p + 1}of${parts}.csv`;
    await saveFile(buildCsv(slice), name);
  }
  return parts;
}

const stamp = () => new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
const perFileValue = () => Math.max(0, parseInt(perFileEl.value, 10) || 0);

downloadBtn.onclick = async () => {
  const parts = await saveCsvFiles(results, perFileValue(), `OfficeAlly_${results.length}rows_${stamp()}`);
  log(`Downloaded ${results.length} rows in ${parts} file(s)`, 'ok');
};

dlFailedBtn.onclick = async () => {
  await saveFile(failedLinks.join('\n'), `OfficeAlly_failed_links_${stamp()}.txt`, 'text/plain;charset=utf-8;');
  log(`Downloaded ${failedLinks.length} failed links`, 'ok');
};

retryBtn.onclick = () => {
  linksEl.value = failedLinks.join('\n');
  log('Failed links upar box me daal diye, Start dabao');
};

function persistSaved() {
  chrome.storage.local.set({ savedCount });
}

async function autoSaveCheck(final = false) {
  const n = perFileValue();
  if (!autoSaveEl.checked || n <= 0) return;
  while (results.length - savedCount >= n || (final && results.length > savedCount)) {
    const from = savedCount;
    const to = Math.min(results.length, from + n);
    savedCount = to;
    persistSaved();
    await saveCsvFiles(results.slice(from, to), 0, `OfficeAlly_rows${from + 1}-${to}_${stamp()}`);
    log(`Auto-saved rows ${from + 1}-${to}`, 'ok');
  }
}

// ---------- controls ----------
document.querySelectorAll('.chip').forEach((c) => {
  c.onclick = () => { workersEl.value = c.dataset.w; };
});

startBtn.onclick = () => {
  const urls = [...new Set(linksEl.value.split('\n').map((l) => l.trim()).filter((l) => l.startsWith('http')))];
  if (!urls.length) { log('Links paste karo', 'err'); return; }

  const workers = Math.max(1, Math.min(30, parseInt(workersEl.value, 10) || 1));
  const delayMs = Math.max(0, (parseFloat(delayEl.value) || 0) * 1000);
  setRunning(true);
  logEl.innerHTML = '';
  failedLinks = [];
  renderFailed();
  barFill.style.width = '0%';
  log(`Starting ${urls.length} links | ${workers} windows | extra delay ${delayMs / 1000}s`);
  chrome.runtime.sendMessage({ action: 'startBulk', urls, delayMs, workers });
};

stopBtn.onclick = () => {
  chrome.runtime.sendMessage({ action: 'stop' });
  stopBtn.disabled = true;
  statusEl.textContent = 'Stopping...';
  log('Stop requested', 'err');
};

clearBtn.onclick = () => {
  if (running) { log('Pehle Stop karo', 'err'); return; }
  results = [];
  failedLinks = [];
  savedCount = 0;
  persistSaved();
  chrome.runtime.sendMessage({ action: 'clear' });
  renderFailed();
  renderTable();
  barFill.style.width = '0%';
  runCountEl.textContent = '0 / 0';
  log('Results cleared');
};

// ---------- messages from background ----------
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'log') log(msg.text, msg.type || '');
  if (msg.action === 'result' && msg.data) {
    results.push(msg.data);
    renderTable();
    autoSaveCheck();
  }
  if (msg.action === 'progress') {
    runCountEl.textContent = `${msg.ok} / ${msg.total}`;
    barFill.style.width = msg.total ? `${Math.round((msg.ok / msg.total) * 100)}%` : '0%';
  }
  if (msg.action === 'failed') {
    failedLinks = msg.urls || [];
    renderFailed();
  }
  if (msg.action === 'done') {
    setRunning(false);
    statusEl.textContent = 'Done';
    log(`All done ✓  Total saved: ${results.length} | Failed: ${failedLinks.length}`, 'ok');
    autoSaveCheck(true);
  }
});

// ---------- restore state on open ----------
chrome.storage.local.get('savedCount').then((s) => {
  savedCount = s.savedCount || 0;
});
chrome.runtime.sendMessage({ action: 'getState' }, (res) => {
  void chrome.runtime.lastError;
  if (!res) return;
  results = res.results || [];
  failedLinks = res.failed || [];
  if (savedCount > results.length) savedCount = 0;
  setRunning(!!res.running);
  if (res.running) {
    runCountEl.textContent = `${res.ok} / ${res.total}`;
    barFill.style.width = res.total ? `${Math.round((res.ok / res.total) * 100)}%` : '0%';
  }
  renderFailed();
  renderTable();
  if (results.length) log(`${results.length} saved rows restore hui`);
});

updateButtons();

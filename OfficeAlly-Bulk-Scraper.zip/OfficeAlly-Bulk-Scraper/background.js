// ===== State (persisted in chrome.storage.local so panel reload / worker restart keeps data) =====
let running = false;
let shouldStop = false;
let results = [];
let failedUrls = [];
let runTotal = 0;
let runOk = 0;

const ready = chrome.storage.local.get(['results', 'failed']).then((s) => {
  results = s.results || [];
  failedUrls = s.failed || [];
});

let persistTimer = null;
function persist(now = false) {
  clearTimeout(persistTimer);
  const save = () => chrome.storage.local.set({ results, failed: failedUrls });
  if (now) save();
  else persistTimer = setTimeout(save, 500);
}

function send(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {});
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// ===== Open / focus panel =====
chrome.action.onClicked.addListener(async () => {
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL('panel.html') });
  if (tabs.length) {
    chrome.tabs.update(tabs[0].id, { active: true });
    chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    chrome.tabs.create({ url: chrome.runtime.getURL('panel.html') });
  }
});

// Keep-alive port from the panel
chrome.runtime.onConnect.addListener((port) => {
  port.onMessage.addListener(() => {});
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'startBulk') {
    if (running) return;
    runBulk(msg.urls || [], msg.delayMs || 0, Math.max(1, Math.min(30, msg.workers || 1)));
  } else if (msg.action === 'stop') {
    shouldStop = true;
  } else if (msg.action === 'clear') {
    results = [];
    failedUrls = [];
    persist(true);
  } else if (msg.action === 'getState') {
    ready.then(() =>
      sendResponse({ running, results, failed: failedUrls, total: runTotal, ok: runOk })
    );
    return true;
  }
});

// ===== Page scraper (injected into the page) =====
function pageScrape() {
  const data = {
    'Transaction ID': '',
    'Member Name': '',
    'Member ID': '',
    'Date of Birth': '',
    'Gender': '',
    'Address': '',
    'Group Number': '',
    'Plan Begin Date': '',
    'Plan Name': '',
    'Payer': '',
    'Coverage Status': '',
    'Identifier Code': ''
  };

  const titleEl = document.querySelector('.summary__value');
  if (titleEl) {
    const t = (titleEl.innerText || '').trim();
    if (/Transaction ID/i.test(t)) data['Transaction ID'] = t.replace(/Transaction ID:?/i, '').trim();
  }
  if (!data['Transaction ID']) {
    const m = (document.body.innerText || '').match(/Transaction ID[:\s]*([A-Z0-9\-]+)/i);
    if (m) data['Transaction ID'] = m[1].trim();
  }

  document.querySelectorAll('.summary__group').forEach((group) => {
    const label = (group.querySelector('.summary__label')?.innerText || '').trim();
    const value = (group.querySelector('.summary__value')?.innerText || '').trim().replace(/\n+/g, ' ');
    if (!label || !value) return;
    const l = label.toLowerCase();
    if (l.includes('member name') || l === 'name') data['Member Name'] = value;
    else if (l.includes('member id') || l.includes('subscriber id') || l === 'id') data['Member ID'] = value;
    else if (l.includes('date of birth') || l.includes('dob') || l.includes('birth')) data['Date of Birth'] = value;
    else if (l.includes('gender') || l.includes('sex')) data['Gender'] = value;
    else if (l.includes('address')) data['Address'] = value;
    else if (l.includes('group number') || l.includes('group #') || l.includes('group id')) data['Group Number'] = value;
    else if (l.includes('plan begin') || l.includes('effective') || l.includes('start date')) data['Plan Begin Date'] = value;
    else if (l.includes('plan name') || l.includes('plan type')) data['Plan Name'] = value;
    else if (l.includes('identifier code') || l.includes('identifier')) data['Identifier Code'] = value;
    else if (l.includes('transaction')) data['Transaction ID'] = data['Transaction ID'] || value;
    else data[label] = value;
  });

  const body = document.body.innerText || '';
  const fill = (key, re) => {
    if (data[key]) return;
    const m = body.match(re);
    if (m) data[key] = m[1].trim();
  };
  fill('Member Name', /Member Name[:\s]*([^\n]+)/i);
  fill('Member ID', /(?:Member ID|Subscriber ID)[:\s]*([A-Z0-9\-]+)/i);
  fill('Date of Birth', /(?:Date of Birth|DOB)[:\s]*([0-9\/\-]+)/i);
  fill('Gender', /Gender[:\s]*(Male|Female|M|F|Other)/i);
  fill('Address', /Address[:\s]*([^\n]+)/i);
  fill('Group Number', /Group (?:Number|#|ID)[:\s]*([A-Z0-9\-]+)/i);
  fill('Plan Begin Date', /(?:Plan Begin Date|Effective Date|Start Date)[:\s]*([0-9\/\-]+)/i);
  fill('Plan Name', /Plan Name[:\s]*([^\n]+)/i);

  const payerBtn = document.querySelector('button.btn.payer, button.payer, .btn.payer');
  if (payerBtn) {
    const nameEl = payerBtn.querySelector('.fs-18, .fw-500, p:not(.payer__label)');
    if (nameEl) data['Payer'] = nameEl.innerText.trim();
    else {
      const all = payerBtn.innerText.replace(/Payer/i, '').replace(/Active Coverage|Inactive/i, '').trim();
      if (all) data['Payer'] = all;
    }
    const statusEl = payerBtn.querySelector('.payer__status, .payer__coverage');
    if (statusEl) data['Coverage Status'] = statusEl.innerText.trim();
  }
  if (!data['Coverage Status'] && /Active Coverage/i.test(body)) data['Coverage Status'] = 'Active Coverage';
  if (!data['Payer']) {
    const m = body.match(/Payer[:\s]*([^\n]+)/i);
    if (m) data['Payer'] = m[1].replace(/Active Coverage|Inactive/i, '').trim();
  }

  if (!data['Identifier Code']) {
    const idTitle = Array.from(document.querySelectorAll('.subgroup__title, .subgroup__pill, span, div, p, label'))
      .find((el) => /Identifier Code/i.test(el.innerText || '') && (el.innerText || '').trim().length < 40);
    if (idTitle) {
      const group = idTitle.closest('.subgroup, .summary__group, [class*="subgroup"], [class*="group"]') || idTitle.parentElement;
      if (group) {
        const candidates = group.querySelectorAll('.subgroup__value, .summary__value, .fs-14, .fs-16, .fw-500, span, p, div');
        for (const c of candidates) {
          const txt = (c.innerText || '').trim();
          if (txt && !/Identifier Code/i.test(txt) && txt.length > 1 && txt.length < 50) {
            data['Identifier Code'] = txt;
            break;
          }
        }
        if (!data['Identifier Code'] && idTitle.nextElementSibling) {
          const next = (idTitle.nextElementSibling.innerText || '').trim();
          if (next && !/Identifier Code/i.test(next)) data['Identifier Code'] = next;
        }
      }
    }
    if (!data['Identifier Code']) {
      const m = body.match(/Identifier Code[:\s]*([A-Z0-9\-]+)/i);
      if (m) data['Identifier Code'] = m[1].trim();
    }
  }
  return data;
}

async function scrapeTab(tabId) {
  try {
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId }, func: pageScrape });
    return result || null;
  } catch (e) {
    return null;
  }
}

// ===== Tab helpers =====
// Registers the listener BEFORE kicking off navigation so a fast load is never missed.
function loadTab(tabId, kick) {
  return new Promise((resolve) => {
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      setTimeout(resolve, 1500);
    };
    const timer = setTimeout(finish, 15000);
    const listener = (tid, info) => {
      if (tid === tabId && info.status === 'complete') finish();
    };
    chrome.tabs.onUpdated.addListener(listener);
    Promise.resolve(kick()).catch(finish);
  });
}

const MAX_WAIT_MS = 180000; // max 3 min per link
const isGood = (d) => !!(d && d['Member Name'] && d['Member ID']);

async function processOne(tabId, url, delayMs) {
  await loadTab(tabId, () => chrome.tabs.update(tabId, { url }));

  const start = Date.now();
  let coreSince = 0;
  let reloaded = 0;

  while (Date.now() - start < MAX_WAIT_MS) {
    if (shouldStop) return null;

    const d = await scrapeTab(tabId);
    if (isGood(d)) {
      if (d['Payer']) {
        if (delayMs > 0) await sleep(delayMs);
        return d;
      }
      if (!coreSince) coreSince = Date.now();
      if (Date.now() - coreSince > 6000) return d;
    }

    const elapsed = Date.now() - start;
    if (elapsed > 60000 * (reloaded + 1) && reloaded < 2) {
      reloaded++;
      await loadTab(tabId, () => chrome.tabs.reload(tabId));
      coreSince = 0;
    }
    await sleep(1000);
  }
  return null;
}

// ===== Worker pool: each worker owns one small browser window =====
async function worker(idx, urls, delayMs, label, failed, ctx) {
  let win;
  try {
    win = await chrome.windows.create({
      url: 'about:blank',
      focused: false,
      width: 520,
      height: 420,
      left: 20 + (idx % 10) * 40,
      top: 20 + (idx % 10) * 30
    });
  } catch (e) {
    send({ action: 'log', type: 'err', text: `Window ${idx + 1} open nahi hui` });
    return;
  }
  const tabId = win.tabs[0].id;

  try {
    await sleep(idx * 1200); // stagger starts so site isn't hit all at once
    while (!shouldStop) {
      const i = ctx.next++;
      if (i >= urls.length) break;
      const url = urls[i];
      let data = null;
      try {
        data = await processOne(tabId, url, delayMs);
      } catch (e) {
        data = null;
      }
      if (shouldStop) break;

      ctx.finished++;
      if (isGood(data)) {
        data['Source Link'] = url;
        results.push(data);
        runOk++;
        persist();
        send({ action: 'result', data });
        send({ action: 'progress', ok: runOk, total: runTotal });
        send({ action: 'log', type: 'ok', text: `✓ W${idx + 1} ${label} ${ctx.finished}/${urls.length} — ${data['Member Name']}` });
      } else {
        failed.push(url);
        send({ action: 'log', type: 'err', text: `✗ W${idx + 1} ${label} ${ctx.finished}/${urls.length} — fail → end me retry hoga` });
      }
    }
  } finally {
    try { await chrome.windows.remove(win.id); } catch (e) {}
  }
}

async function runPass(urls, workers, delayMs, label) {
  const failed = [];
  const ctx = { next: 0, finished: 0 };
  const n = Math.min(workers, urls.length);
  send({ action: 'log', text: `${label} ${urls.length} links | ${n} windows` });
  await Promise.all(
    Array.from({ length: n }, (_, w) => worker(w, urls, delayMs, label, failed, ctx))
  );
  return failed;
}

async function runBulk(urls, delayMs, workers) {
  await ready;
  running = true;
  shouldStop = false;
  try {
    const known = new Set(results.map((r) => r['Source Link']));
    const unique = [...new Set(urls)];
    const todo = unique.filter((u) => !known.has(u));
    const skipped = unique.length - todo.length;
    if (skipped) send({ action: 'log', text: `${skipped} link pehle se scrape hain, skip kiye` });

    runTotal = todo.length;
    runOk = 0;
    failedUrls = [];
    send({ action: 'progress', ok: 0, total: runTotal });

    let failed = [];
    if (todo.length) {
      failed = await runPass(todo, workers, delayMs, '[Pass 1]');
      for (let round = 1; round <= 2 && failed.length && !shouldStop; round++) {
        send({ action: 'log', text: `Retry round ${round}: ${failed.length} failed links dobara...` });
        failed = await runPass(failed, workers, delayMs, `[Retry ${round}]`);
      }
    } else {
      send({ action: 'log', text: 'Scrape karne ke liye koi naya link nahi' });
    }

    failedUrls = failed;
    persist(true);
    send({ action: 'failed', urls: failed });
  } finally {
    running = false;
    send({ action: 'done' });
  }
}
